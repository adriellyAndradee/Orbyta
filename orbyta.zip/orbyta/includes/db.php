<?php
declare(strict_types=1);

/* Configuração: altere aqui ou use variáveis de ambiente (DB_HOST, DB_NAME, DB_USER, DB_PASS). */
const DB_HOST_PADRAO = '127.0.0.1';
const DB_NAME_PADRAO = 'orbyta';
const DB_USER_PADRAO = 'root';
const DB_PASS_PADRAO = '';

function conectar(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $host = getenv('DB_HOST') ?: DB_HOST_PADRAO;
        $nome = getenv('DB_NAME') ?: DB_NAME_PADRAO;
        $pdo = new PDO(
            "mysql:host=$host;dbname=$nome;charset=utf8mb4",
            getenv('DB_USER') ?: DB_USER_PADRAO,
            getenv('DB_PASS') !== false ? getenv('DB_PASS') : DB_PASS_PADRAO,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    }
    return $pdo;
}

/** Escapa saída HTML (previne XSS). */
function h(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Valida e higieniza os dados do contato (usado pelo site e pelo painel).
 * @return array{0: array<string,string>, 1: array<string,string>} [dados, erros]
 */
function validar_contato(array $in): array
{
    $d = [];
    foreach (['nome', 'email', 'telefone', 'mensagem'] as $campo) {
        $d[$campo] = trim((string)($in[$campo] ?? ''));
    }
    $e = [];

    if (mb_strlen($d['nome']) < 3 || mb_strlen($d['nome']) > 100) {
        $e['nome'] = 'Informe seu nome completo (mínimo 3 caracteres).';
    }
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($d['email']) > 150) {
        $e['email'] = 'Informe um e-mail válido, como nome@empresa.com.br.';
    }
    $digitos = preg_replace('/\D/', '', $d['telefone']);
    if (strlen($digitos) < 10 || strlen($digitos) > 11) {
        $e['telefone'] = 'Informe o telefone com DDD, ex.: (41) 99999-9999.';
    }
    if (mb_strlen($d['mensagem']) < 10 || mb_strlen($d['mensagem']) > 2000) {
        $e['mensagem'] = 'Escreva entre 10 e 2000 caracteres.';
    }
    return [$d, $e];
}
