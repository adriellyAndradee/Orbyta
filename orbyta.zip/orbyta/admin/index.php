<?php
declare(strict_types=1);
session_start();
require __DIR__ . '/../includes/db.php';

/* CSRF: token por sessão, exigido em toda ação que altera dados. */
$_SESSION['csrf'] ??= bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

function voltar(string $msg, string $tipo = 'ok'): never
{
    $_SESSION['flash'] = [$tipo, $msg];
    header('Location: index.php');
    exit;
}

try {
    $pdo = conectar();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
            voltar('Sessão expirada. Tente de novo.', 'erro');
        }
        $acao = $_POST['acao'] ?? '';
        $id = (int)($_POST['id'] ?? 0);

        if ($acao === 'excluir' && $id > 0) {
            $pdo->prepare('DELETE FROM contatos WHERE id = ?')->execute([$id]);
            voltar('Contato excluído.');
        }
        if (in_array($acao, ['criar', 'atualizar'], true)) {
            [$d, $erros] = validar_contato($_POST);
            if ($erros) {
                voltar(implode(' ', $erros), 'erro');
            }
            if ($acao === 'criar') {
                $pdo->prepare('INSERT INTO contatos (nome,email,telefone,mensagem) VALUES (:nome,:email,:telefone,:mensagem)')->execute($d);
                voltar('Contato criado.');
            }
            $d['id'] = $id;
            $pdo->prepare('UPDATE contatos SET nome=:nome,email=:email,telefone=:telefone,mensagem=:mensagem WHERE id=:id')->execute($d);
            voltar('Contato atualizado.');
        }
    }

    $busca = trim((string)($_GET['q'] ?? ''));
    $editarId = (int)($_GET['editar'] ?? 0);
    $edicao = null;
    if ($editarId > 0) {
        $st = $pdo->prepare('SELECT * FROM contatos WHERE id = ?');
        $st->execute([$editarId]);
        $edicao = $st->fetch() ?: null;
    }

    $sql = 'SELECT * FROM contatos';
    $params = [];
    if ($busca !== '') {
        $sql .= ' WHERE nome LIKE :q OR email LIKE :q OR telefone LIKE :q OR mensagem LIKE :q';
        $params['q'] = "%$busca%";
    }
    $st = $pdo->prepare($sql . ' ORDER BY criado_em DESC LIMIT 200');
    $st->execute($params);
    $contatos = $st->fetchAll();
    $erroBanco = null;
} catch (PDOException $ex) {
    error_log('[Orbyta admin] ' . $ex->getMessage());
    $contatos = [];
    $erroBanco = 'Não foi possível conectar ao banco. Confira includes/db.php e se importou database/schema.sql.';
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contatos | Painel Orbyta</title>
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    .adm{padding:2rem 0 4rem}
    .adm__top{display:flex;flex-wrap:wrap;gap:1rem;justify-content:space-between;align-items:center;margin-bottom:1.5rem}
    .adm h1{font-size:1.8rem;margin:0}
    .aviso{padding:.8rem 1rem;border-radius:10px;font-weight:600;margin-bottom:1rem}
    .aviso.ok{background:#DDF6EE;color:#0B6B53}.aviso.erro{background:#FBE3E6;color:#8E1B29}
    .busca{display:flex;gap:.5rem}.busca input{min-width:0}
    .tabela{overflow-x:auto;background:#fff;border:1px solid var(--line);border-radius:var(--radius)}
    table{width:100%;border-collapse:collapse;font-size:.95rem}
    th,td{padding:.8rem 1rem;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}
    th{background:#EEF2F8;font-family:var(--font-d);font-size:.85rem}
    td.msg{min-width:220px;max-width:360px}
    .acoes{display:flex;gap:.4rem;white-space:nowrap}
    .btn--out{background:#fff;color:var(--ink);box-shadow:inset 0 0 0 1.5px #B9C4D6}.btn--out:hover{background:#EEF2F8}
    .btn--del{background:var(--danger)}.btn--del:hover{background:#9E1F2D}
    .form{margin-bottom:2rem}
    .vazio{padding:2rem;text-align:center;color:var(--muted)}
  </style>
</head>
<body>
<main class="container adm">
  <div class="adm__top">
    <h1>Contatos recebidos</h1>
    <div class="busca">
      <form method="get" class="busca" role="search">
        <input type="search" name="q" value="<?= h($busca) ?>" placeholder="Buscar contato" aria-label="Buscar contato">
        <button class="btn btn--sm">Buscar</button>
      </form>
      <a class="btn btn--sm btn--out" href="../">Ver site</a>
    </div>
  </div>

  <?php if ($erroBanco): ?><p class="aviso erro" role="alert"><?= h($erroBanco) ?></p><?php endif; ?>
  <?php if ($flash): ?><p class="aviso <?= h($flash[0]) ?>" role="status"><?= h($flash[1]) ?></p><?php endif; ?>

  <form method="post" class="form" id="form-contato">
    <h2 style="font-size:1.2rem"><?= $edicao ? 'Editar contato #' . (int)$edicao['id'] : 'Novo contato' ?></h2>
    <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
    <input type="hidden" name="acao" value="<?= $edicao ? 'atualizar' : 'criar' ?>">
    <?php if ($edicao): ?><input type="hidden" name="id" value="<?= (int)$edicao['id'] ?>"><?php endif; ?>
    <div class="field"><label for="nome">Nome</label><input id="nome" name="nome" required minlength="3" value="<?= h($edicao['nome'] ?? '') ?>"></div>
    <div class="field"><label for="email">E-mail</label><input id="email" name="email" type="email" required value="<?= h($edicao['email'] ?? '') ?>"></div>
    <div class="field"><label for="telefone">Telefone</label><input id="telefone" name="telefone" required value="<?= h($edicao['telefone'] ?? '') ?>"></div>
    <div class="field"><label for="mensagem">Mensagem</label><textarea id="mensagem" name="mensagem" required minlength="10"><?= h($edicao['mensagem'] ?? '') ?></textarea></div>
    <div class="acoes">
      <button class="btn"><?= $edicao ? 'Salvar alterações' : 'Criar contato' ?></button>
      <?php if ($edicao): ?><a class="btn btn--out" href="index.php">Cancelar</a><?php endif; ?>
    </div>
  </form>

  <div class="tabela">
  <?php if (!$contatos): ?>
    <p class="vazio">Nenhum contato encontrado. Envie uma mensagem pelo formulário do site ou crie um contato acima.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Data</th><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Mensagem</th><th>Ações</th></tr></thead>
      <tbody>
      <?php foreach ($contatos as $c): ?>
        <tr>
          <td><?= h(date('d/m/Y H:i', strtotime($c['criado_em']))) ?></td>
          <td><?= h($c['nome']) ?></td>
          <td><a href="mailto:<?= h($c['email']) ?>"><?= h($c['email']) ?></a></td>
          <td><?= h($c['telefone']) ?></td>
          <td class="msg"><?= nl2br(h($c['mensagem'])) ?></td>
          <td class="acoes">
            <a class="btn btn--sm btn--out" href="?editar=<?= (int)$c['id'] ?>#form-contato">Editar</a>
            <form method="post" onsubmit="return confirm('Excluir o contato de <?= h(addslashes($c['nome'])) ?>?')">
              <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
              <input type="hidden" name="acao" value="excluir">
              <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="btn btn--sm btn--del">Excluir</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
  </div>
</main>
</body>
</html>
