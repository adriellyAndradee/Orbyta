<?php
declare(strict_types=1);
require __DIR__ . '/../includes/db.php';

header('Content-Type: application/json; charset=utf-8');

function responder(int $codigo, array $corpo): never
{
    http_response_code($codigo);
    echo json_encode($corpo, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(405, ['ok' => false, 'message' => 'Método não permitido.']);
}

// Honeypot: robôs preenchem o campo oculto; fingimos sucesso e não gravamos.
if (!empty($_POST['website'])) {
    responder(200, ['ok' => true, 'message' => 'Mensagem enviada.']);
}

[$dados, $erros] = validar_contato($_POST);
if ($erros) {
    responder(422, ['ok' => false, 'errors' => $erros, 'message' => 'Corrija os campos destacados.']);
}

try {
    $stmt = conectar()->prepare(
        'INSERT INTO contatos (nome, email, telefone, mensagem) VALUES (:nome, :email, :telefone, :mensagem)'
    );
    $stmt->execute($dados);
    responder(201, ['ok' => true, 'message' => 'Mensagem enviada.']);
} catch (Throwable $ex) {
    error_log('[Orbyta] ' . $ex->getMessage());
    responder(500, ['ok' => false, 'message' => 'Erro ao salvar sua mensagem. Tente novamente em instantes.']);
}
