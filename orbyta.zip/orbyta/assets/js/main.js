/* Orbyta — interações da landing page */
(() => {
  'use strict';

  /* ---------- Menu mobile ---------- */
  const toggle = document.getElementById('menuToggle');
  const menu = document.getElementById('menu');
  const setMenu = (open) => {
    menu.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  };
  toggle.addEventListener('click', () => setMenu(!menu.classList.contains('is-open')));
  menu.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });

  document.getElementById('ano').textContent = new Date().getFullYear();

  /* ---------- Contadores (animam quando entram na tela) ---------- */
  const fmt = (n, dec) => n.toLocaleString('pt-BR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  const counters = document.querySelectorAll('[data-count]');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  if ('IntersectionObserver' in window && !reduce) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        io.unobserve(entry.target);
        const el = entry.target;
        const alvo = parseFloat(el.dataset.count);
        const dec = parseInt(el.dataset.dec || '0', 10);
        const inicio = performance.now();
        const passo = (agora) => {
          const t = Math.min((agora - inicio) / 1200, 1);
          el.textContent = fmt(alvo * (1 - Math.pow(1 - t, 3)), dec);
          if (t < 1) requestAnimationFrame(passo);
        };
        requestAnimationFrame(passo);
      });
    }, { threshold: 0.6 });
    counters.forEach((c) => io.observe(c));
  }

  /* ---------- Formulário: máscara, validação e envio ---------- */
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');
  const btn = document.getElementById('btnEnviar');
  const modal = document.getElementById('modal');

  const regras = {
    nome: (v) => v.trim().length >= 3 || 'Informe seu nome completo (mínimo 3 caracteres).',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Informe um e-mail válido, como nome@empresa.com.br.',
    telefone: (v) => { const d = v.replace(/\D/g, ''); return (d.length === 10 || d.length === 11) || 'Informe o telefone com DDD, ex.: (41) 99999-9999.'; },
    mensagem: (v) => v.trim().length >= 10 || 'Escreva pelo menos 10 caracteres para entendermos sua necessidade.'
  };

  const mostrarErro = (campo, msg) => {
    const input = form.elements[campo];
    const wrap = input.closest('.field');
    wrap.classList.toggle('invalid', Boolean(msg));
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    document.getElementById(`${campo}-erro`).textContent = msg || '';
  };

  const validarCampo = (campo) => {
    const r = regras[campo](form.elements[campo].value);
    mostrarErro(campo, r === true ? '' : r);
    return r === true;
  };

  form.elements.telefone.addEventListener('input', (e) => {
    let d = e.target.value.replace(/\D/g, '').slice(0, 11);
    if (d.length > 6) d = d.replace(d.length > 10 ? /(\d{2})(\d{5})(\d+)/ : /(\d{2})(\d{4})(\d+)/, '($1) $2-$3');
    else if (d.length > 2) d = d.replace(/(\d{2})(\d+)/, '($1) $2');
    e.target.value = d;
  });

  Object.keys(regras).forEach((campo) => {
    form.elements[campo].addEventListener('blur', () => validarCampo(campo));
    form.elements[campo].addEventListener('input', () => {
      if (form.elements[campo].closest('.field').classList.contains('invalid')) validarCampo(campo);
    });
  });

  const abrirModal = (titulo, texto) => {
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = texto;
    modal.showModal();
  };
  document.getElementById('modalFechar').addEventListener('click', () => modal.close());
  modal.addEventListener('click', (e) => { if (e.target === modal) modal.close(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    status.textContent = '';
    status.className = 'form__status';

    const validos = Object.keys(regras).map(validarCampo);
    if (validos.includes(false)) {
      form.querySelector('.invalid input, .invalid textarea')?.focus();
      return;
    }

    btn.disabled = true;
    btn.textContent = 'Enviando…';
    try {
      const resp = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
      const data = await resp.json();
      if (resp.ok && data.ok) {
        form.reset();
        abrirModal('Mensagem enviada', 'Recebemos seu contato e responderemos em até 1 dia útil.');
      } else {
        Object.entries(data.errors || {}).forEach(([c, m]) => mostrarErro(c, m));
        status.textContent = data.message || 'Não foi possível enviar. Tente novamente.';
        status.classList.add('is-error');
      }
    } catch (err) {
      status.textContent = 'Servidor indisponível. Verifique se o PHP e o MySQL estão rodando.';
      status.classList.add('is-error');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Enviar mensagem';
    }
  });
})();
