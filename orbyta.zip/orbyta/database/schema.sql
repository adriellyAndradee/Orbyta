CREATE DATABASE IF NOT EXISTS orbyta CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE orbyta;

CREATE TABLE IF NOT EXISTS contatos (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(100)  NOT NULL,
  email         VARCHAR(150)  NOT NULL,
  telefone      VARCHAR(20)   NOT NULL,
  mensagem      TEXT          NOT NULL,
  criado_em     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP     NULL ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_criado (criado_em)
) ENGINE=InnoDB;
