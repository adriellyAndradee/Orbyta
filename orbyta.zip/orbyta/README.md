# Orbyta Tecnologia — Landing Page B2B + Back-end PHP/MySQL

Landing page responsiva (HTML5, CSS3, JavaScript) para uma empresa fictícia de tecnologia B2B, com integração PHP + MySQL e painel administrativo (CRUD).

## Como rodar (5 minutos)

1. Instale o **XAMPP** (ou Laragon/WAMP) e inicie **Apache** e **MySQL**.
2. Copie a pasta do projeto para `htdocs/orbyta` (XAMPP).
3. Abra `http://localhost/phpmyadmin`, aba **Importar**, e importe `database/schema.sql`.
4. Se o seu MySQL tiver senha, ajuste `includes/db.php` (no XAMPP padrão, usuário `root` e senha vazia já funcionam).
5. Acesse:
   - Site: `http://localhost/orbyta/`
   - Painel: `http://localhost/orbyta/admin/`

Sem PHP, a landing page abre normalmente (basta abrir o `index.html`), mas o envio do formulário mostra aviso de servidor indisponível. O GitHub Pages não executa PHP: use o GitHub para guardar o código e um host com PHP (ex.: InfinityFree) para publicar.

## Estrutura

```
index.html              Landing page
assets/css/style.css    Estilos (tokens, mobile-first)
assets/js/main.js       Menu mobile, validação, máscara, contadores, modal, envio via fetch
api/contato.php         Endpoint do formulário (Nível 1 e 2)
admin/index.php         Painel CRUD (Nível 3)
includes/db.php         Conexão PDO, validação compartilhada e escape de HTML
database/schema.sql     Criação do banco e da tabela
```

## Requisitos atendidos

| Requisito | Onde |
|---|---|
| Cabeçalho com logo e menu | `index.html` (header), menu hambúrguer no mobile |
| Hero com CTA | Seção principal com dois botões |
| 3+ serviços | Cloud, Cibersegurança, Automação |
| Sobre a empresa | Texto + indicadores animados |
| Formulário (Nome, E-mail, Telefone, Mensagem) | Seção Contato |
| Rodapé | `footer` com link para o painel |
| Interações JS | Menu mobile, validação, máscara de telefone, modal, contador animado |
| Nível 1: validação PHP | `validar_contato()` + `api/contato.php` |
| Nível 2: MySQL | Tabela `contatos`, gravação via PDO |
| Nível 3: CRUD sem login | `admin/index.php` (criar, listar/buscar, editar, excluir) |

## Decisões técnicas (para a apresentação)

- **Sem frameworks.** O desafio pede HTML/CSS/JS puros. Isso mostra domínio dos fundamentos e deixa o projeto leve (sem build, sem dependências).
- **Mobile-first.** O CSS base é o do celular; `@media (min-width: 900px)` expande para desktop. Layout com CSS Grid e Flexbox, tipografia fluida com `clamp()`.
- **Design tokens em variáveis CSS.** Cores, raio e fontes ficam em `:root`, o que facilita trocar a identidade visual em um só lugar.
- **Acessibilidade.** HTML semântico, link "ir para o conteúdo", `label` em todos os campos, erros com `role="alert"`, foco visível, `aria-expanded` no menu e respeito a `prefers-reduced-motion`.
- **Validação em duas camadas.** O JavaScript dá resposta imediata ao usuário; o PHP valida de novo, pois a validação do navegador pode ser contornada. As duas usam as mesmas regras.
- **Segurança.** PDO com *prepared statements* (contra SQL Injection), `htmlspecialchars` em toda saída (contra XSS), token CSRF nas ações do painel, campo *honeypot* contra robôs e erros técnicos só no log, nunca na tela.
- **Uma função de validação compartilhada** (`validar_contato`) usada pelo site e pelo painel, evitando regras duplicadas.
- **Painel sem login**, como o desafio permite. Em produção, ele precisaria de autenticação (ex.: `password_hash` + sessão) e proteção por HTTPS.
- **Envio assíncrono com `fetch`.** O usuário não sai da página; o resultado aparece em um modal acessível (`<dialog>` nativo).

## Próximos passos possíveis

Login no painel, paginação, envio de e-mail de confirmação (PHPMailer) e exportação CSV dos contatos.
